sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("MyTest.MyFioriApp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);